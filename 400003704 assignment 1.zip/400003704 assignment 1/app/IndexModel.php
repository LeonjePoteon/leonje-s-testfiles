<?php
 class IndexModel extends observable_model
 {
    public function getall():array
    {
        $data = $this->loadData(DATA_DIR.'/courses.json');
        
        
        // get most popular and favourite
        $popular_column= array_column($data['courses'],3);
        $recommended_column = array_column($data['courses'],2);
        $remainder = $data['courses'];

        array_multisort($recommended_column,SORT_DESC,$data['courses']);
        $recommended = array_slice($data['courses'],0,8);

        array_multisort($popular_column,SORT_DESC,$remainder);
        $popular = array_slice($remainder,0,8);

        return['popular'=>$popular,'recommended'=>$recommended];


    }

    public function getRecord(string $ID):array
    {
        return[];
    }
 }