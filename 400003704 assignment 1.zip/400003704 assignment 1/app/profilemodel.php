<?php
    class profilemodel extends observable_model
    {
        public function getAll():array
        {
            return [];
        }

        public function getRecord(string $ID): array
        {
            return [];
        }
    }