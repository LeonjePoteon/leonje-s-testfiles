<?php
 class profilecontroller extends controllerClass
 {
     public function execute()
     {
        SessionClass::create();



        $session = new sessionClass();
        $session-> remove('user');
        $v = new view();
        $v-> setTemplate(TPL_DIR.'/profile.tpl.php');



        $this->setModel(new profileModel());
        $this->setView($v);

        $this->model->attach($this->view);

        $user = $session->see('user');


        if ($session->accessiblle($user,'profile'))
        {
            $data = $this->model->getAll();
            $this->model-> updatethechangeData($data);
            $this->model->notify();
        
        }
        else
        {
            $v->setTemplate(TPL_DIR.'/login.tpl.php');
            $v->display();

        }
     }
 }