<?php
class indexcontroller extends controllerClass
{
    public function execute()
    {
        $v = new view();
        $v ->setTemplate(TPL_DIR.'/index.tpl.php');


        $this->SetModel(new IndexModel());
        $this->setView($v);

        $this->model->attach($this->view);
        $info = $this->model->getAll();
        $this->model->updateThechangedDate($info);
        $this->model->notify();
    }
}