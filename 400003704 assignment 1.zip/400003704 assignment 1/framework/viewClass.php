<?php


class viewClass
{
    private $tpl;

    public function view():void
    {
        $this->$view = new $view;
    }

    public function settemplate(string $filename)
    {
        $this -> $tpl = "$filename";

    }
    
    public function Display()
    {
      echo settemplate()-> $tpl;
    }
    
    public function addVar(string $name,int $value)
    {
       $this->$tpl = $name;
       $this->$tpl = $value; 
      
    }

}