<?php


class viewClass
{
    private $tpl;
    private $info;


    public function view():void
    {
        $this->$view = new $view;
    }

    public function settemplate(string $filename)
    {
        if (!file_exists($filename)) 
        {
            trigger_error('template void (' . $filename . ') No such file exist', E_USER_ERROR);
            exit;
        }
        $this->tpl = $filename;

    }
    
    public function Display()
    {
        extract($this->info);
        require $this->tpl;
        
      //echo settemplate()-> $tpl;
    }
    
    public function addVar(string $name,int $value)
    {
        if (preg_match('/^[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*$/', $name) == 0) {
            trigger_error('Invalid variable name used', E_USER_ERROR);
        }
        $this->info[$name] = $value;
      
    }
     
    public function update(Observable_Model $obs)
    {
       $rec = $obs->giveUpdate();
        foreach ($rec as $k=>$r) {
            $this->addVar($k, $r);
        }
        $this->display();
        
    }
}