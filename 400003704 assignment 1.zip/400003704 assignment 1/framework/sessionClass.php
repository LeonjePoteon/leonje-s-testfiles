<?php
   class SessionClass
   {
      public function Create(int $session)
      {
        $this -> $session = new $session;
        session_begin();

      }


      public function add($name,$value)
      {
         $this->$seesion[$name]=$value;
      }


      public function remove($name)
      {
         if (isset($session[$name])){
            return $session;
         }
         return null;
      }

      public function accessible($user, $page)
      {
        if (in_array($user,$this->access[$page])){
         return true;
        }
        return false;
      }
   }