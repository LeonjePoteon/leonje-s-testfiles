<?php
   class SessionClass
   {
      protected $access = ['profile'=>['testuser',]];


      public static function creat()
      {
         session_begin();
      }

      public function add($name, $value)
      {
         // check to make sure the variable name is valid
         if (preg_match('/^[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*$/', $name) == 0) 
         {
            trigger_error('Invalid variable name used', E_USER_ERROR);
         }
         $_SESS[$name] = $value;
      }

      public function show($name)
      {
         if (isset($_SESS[$name])) {  
            return $_SESS[$name];
         }
         return null;
      }

      public function accessible($user, $page)
      {
         if (in_array($user, $this->access[$page])) {
            return true;
         }
         return false;
      }
      public function remove(string $name)
	{
		if (isset($_SESS[$name])) {
			unset($_SESS[$name]);
		}
	}
   }