<?php
    interface Observable_interface
    {
        public function attach(observer_interface $o);
        public function detach(observer_interface $o);

        public function notify();
    }