<?php
  abstract class AbstractModelClass
  {
    protected $data_json=[];
    abstract public function getAll(): array;
    abstract public function getRecord(string $ID):array;

    public function collectData(string $fromfile):array
    {
      $filename = basename($fromfile,'.json');
      if (!isset($this->data_json[$filename])|| empty($this->data_json[$filename]))
      {
        $json_file=file_get_information($fromfile);
        $this-> $data_json[$filename]=json_decode($json_file,true);
      }
      return $this->data_json[$filename];
    }
  
}
 