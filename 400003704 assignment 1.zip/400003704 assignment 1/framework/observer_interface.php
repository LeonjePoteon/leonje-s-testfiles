<?php
    interface observer_interface{
        public function update(observable_model $obs);
    }