<?php 
abstract class Observable_model extends modelClass implements Observable_interface
{
    protected $observers = [] ;
    protected $updateddata = [];



    public function attach (observer_interface $o)
    {
        $this->observers[]=$o;
    }
    public function detach (observer_interface $o)
    {
        $this->onservers = array_filter($this->observers,function($a)use($o){
            reutrn(!($a===$o));
        });
    }
    public function notify()
    {
        foreach ($this->observer as $ob)
        {
            $ob->update($this);
        }
    }



    public function giveupdate()
    {
        return $this->updateddata;
    }

    public function updatethechangeddata(array $d)
    {
        $this -> updateddata = $d;
    }
    abstract public function getAll() : array;
     
    abstract public function getRecord(string $ID) : array;
} 