<?php 
abstract class Observable_model extends modelClass implements Observable_interface
{
    
} 