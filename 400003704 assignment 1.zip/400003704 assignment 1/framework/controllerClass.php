<?php
  abstract class controller
  {
    protected $model=null;
    protected $view=null;



    public function setModel(observable_model $model)
    {
        $this -> model = $model; 
    }


    public function setView(view $view)
    {
      $this->view = $view;
    }
    abstract function execute();
  }
 